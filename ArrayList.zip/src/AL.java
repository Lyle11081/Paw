import java.util.*;

public class AL {
    public static void main(String[] args) {
        //Array
        int[] numbers = new int[3];
        numbers[0] = 10;
        numbers[1] = 30;
        numbers[2] = 29;
        for (int num : numbers) {
            System.out.println(num);
        }
        // calculate sum
        int sum = 0;
        for (int n : numbers) {
            sum += n;
        }
        System.out.println("Total: " + sum);
        // ArrayList
        ArrayList<Integer> values = new ArrayList<>();
        values.add(90);
        values.add(75);
        values.add(30);
        for (int n : values) {
            System.out.println(n);
            sum += n;
        }
        System.out.println("new Total: " + sum);
        // iterator to fix problem
        Iterator<Integer> iterator = values.iterator();
        while (iterator.hasNext()) {
            int nums = iterator.next();
            if (nums % 10 != 0) {
                iterator.remove();
                System.out.println(nums + " Removed.");
            }
        }
        System.out.println(values);
        // iterator
        ArrayList<String> students = new ArrayList<>();
        students.add("Hadi");
        students.add("Pitiwat");
        students.add("Chin");
        students.add("imran");
        students.add("Janne");
        Iterator<String> itr = students.iterator();
        while (itr.hasNext()) {
            String student = itr.next();
            System.out.println(student);
            if (student.equals("Janne")) {
                itr.remove();
                System.out.println(student + " Removed.");
            }
        }
        System.out.println(students);
    }
}